RK3568 native App v5-r3. Preinstalled Linux/Qt/Wayland/Python/OpenCV/NumPy/RKNNLite required.
Deploy this complete archive to a fresh /userdata/helmet-validation root; verify every manifest member.
Normal icons use src/app/launch.py. Read-only LAN page listens on http://BOARD_IP:8091/.
Boot entry links /etc/init.d/S99zhelmet-app to src/app/autostart.sh after verified deployment.
Boot starts background idle; choose camera/model and start detection in the native App.
No second Pipeline; local controls remain token-protected on loopback. No WiFi credentials included.
