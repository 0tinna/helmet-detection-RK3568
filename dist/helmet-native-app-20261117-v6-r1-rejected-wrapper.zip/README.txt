RK3568 native Qt helmet detection application.
Existing compatible Qt5/qmlscene, Wayland, Python3, OpenCV, NumPy, RKNNLite and camera drivers are required.
Extract the complete bundle to \userdata\helmet-validation\20261117-native-app-v6-r1 and verify manifest.json before first use.
Launch: python3 src/app/launch.py --root \userdata\helmet-validation\20261117-native-app-v6-r1
LAN viewer after the resident service starts: http://BOARD_IP:8091/
Local detection uses the board model and does not need internet or a browser. Physical camera, human display continuity, phone touch and WiFi authentication remain separately validated gates.
