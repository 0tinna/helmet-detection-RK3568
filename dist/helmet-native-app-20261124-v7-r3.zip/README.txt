RK3568 native Qt helmet detection application.
Existing compatible Qt5/qmlscene, Wayland, Python3, OpenCV, NumPy, RKNNLite, camera drivers and network configuration are required.
Extract the complete bundle to /userdata/helmet-validation/20261124-native-app-v7-r3 and verify manifest.json before first use.
Launch: python3 src/app/launch.py --root /userdata/helmet-validation/20261124-native-app-v7-r3
Existing LAN preview after the resident service starts: http://BOARD_IP:8091/
Direct read-only event dashboard from the same LAN: http://BOARD_LAN_IP:8092/
The dashboard shows current alert state and traceable no-hat evidence.
No setup, login, invitation token or external account is required.
Do not expose 8091 or 8092 through router or phone-hotspot forwarding.
Physical camera, human display and same-LAN phone checks remain separate acceptance gates.
