RK3568 native Qt helmet detection application.
Existing compatible Qt5/qmlscene, Wayland, Python3, OpenCV, NumPy, RKNNLite, camera drivers and network configuration are required.
Extract the complete bundle to /userdata/helmet-validation/20261124-native-app-v7-r1 and verify manifest.json before first use.
Launch: python3 src/app/launch.py --root /userdata/helmet-validation/20261124-native-app-v7-r1
Existing LAN preview after the resident service starts: http://BOARD_IP:8091/
Authenticated event archive: http://BOARD_IP:8092/ after router forwarding.
Never place mail.json or public-access.key in a release archive.
Physical camera, human display, SMTP, router NAT and external phone checks remain separate acceptance gates.
