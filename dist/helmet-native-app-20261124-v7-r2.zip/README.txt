RK3568 native Qt helmet detection application.
Existing compatible Qt5/qmlscene, Wayland, Python3, OpenCV, NumPy, RKNNLite, camera drivers and network configuration are required.
Extract the complete bundle to /userdata/helmet-validation/20261124-native-app-v7-r2 and verify manifest.json before first use.
Launch: python3 src/app/launch.py --root /userdata/helmet-validation/20261124-native-app-v7-r2
Existing LAN preview after the resident service starts: http://BOARD_IP:8091/
Authenticated event archive from the same LAN: http://BOARD_LAN_IP:8092/
Do not expose 8091 or 8092 through router or phone-hotspot forwarding.
SMTP probe: python3 src/app/mail_probe.py --root /userdata/helmet-validation/20261124-native-app-v7-r2
Never place mail.json or event-access.key in a release archive.
Physical camera, human display, SMTP and same-LAN phone checks remain separate acceptance gates.
